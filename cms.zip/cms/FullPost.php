<?php require_once("Includes/DB.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php"); ?>
<?php $SearchQueryParameter = $_GET["id"]; ?>
<?php
if(isset($_POST["Submit"])){
 $Name = $_POST["CommenterName"];
 $Email = $_POST["CommenterEmail"];
 $Comment = $_POST["CommenterThoughts"];
 date_default_timezone_set("Asia/Kolkata");
 $CurrentTime=time();
 $DateTime=strftime("%B-%d-%Y %H:%M:%S",$CurrentTime);

 if(empty($Name)||empty($Email)||empty($Comment)){
  $_SESSION["ErrorMessage"]= "All fields must be filled";
  Redirect_to("FullPost.php?id=$SearchQueryParameter");
}elseif (strlen($Comment)>500) {
  $_SESSION["ErrorMessage"]= "Comment length is exceeding 500 charachter limit";
  Redirect_to("FullPost.php?id=$SearchQueryParameter");
}else {
  // Query to insert Comment into database when everything is ok
  global $ConnectingDB;
  $sql = "INSERT INTO comments(datetime,name,email,comment,approvedby,status,post_id)";
  $sql .="VALUES(:dateTime,:name,:email,:comment,'Pending','OFF',:postIdFromURL)";
  $stmt =$ConnectingDB->prepare($sql);
  $stmt->bindValue(':dateTime',$DateTime);
  $stmt->bindValue(':name',$Name);
  $stmt->bindValue(':email',$Email);
  $stmt->bindValue(':comment',$Comment);
    $stmt->bindValue(':postIdFromURL',$SearchQueryParameter);
  $Execute=$stmt->execute();
 var_dump($Execute);
  if($Execute){
  $_SESSION["SuccessMessage"]="Comment Submitted Successfully";
  Redirect_to("FullPost.php?id=$SearchQueryParameter");
}else {
  $_SESSION["ErrorMessage"]= "Something went wrong | Try again!";
  Redirect_to("FullPost.php?id=$SearchQueryParameter");
  }
 }
}//end of submit button if condition
 ?>
  <!DOCTYPE html>
  <html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/93860edfe3.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="Css/Styles.css">
    <title>Full Post Page</title>
  </head>
  <body>
    <!--NAVBAR-->
    <div style="height:10px; background:#27aae1;"></div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
     <div class="container">
      <a href="Blog.php?page=1" class="navbar-brand">AtharvaLele.com</a>
       <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarcollapseCMS">
        <span class="navbar-toggler-icon"></span>
       </button>
    <div class="collapse navbar-collapse" id="navbarcollapseCMS">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
        <a href="Blog.php" class="nav-link">Home</a>
        </li>
        <li class="nav-item">
        <a href="#" class="nav-link">About Us</a>
        </li>
        <li class="nav-item">
        <a href="Blog.php" class="nav-link">Blog</a>
        </li>
        <li class="nav-item">
        <a href="#" class="nav-link">Contact Us</a>
        </li>
        <li class="nav-item">
        <a href="#" class="nav-link">Features</a>
        </li>
        <li class="nav-item">
        <a href="MyProfile.php" class="nav-link"><i class="fas fa-user text-success"></i> My Profile</a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <form class="form-inline d-none d-sm-block" action="Blog.php" >
          <div class="form-group">
          <input class="form-control mr-2" type="text" name="Search" placeholder="Search Here" value="">
          <button class="btn btn-primary" name="SearchButton">Go</button>

          </div>
        </form>
      </ul>
     </div>
     </div>
   </nav>
   <div style="height:10px; background:#27aae1;"></div>
    <!-- NAVBAR END -->
    <!--HEADER-->
<div class="container">
  <div class="row mt-4">

      <!--Main Area-->
    <div class="col-sm-8" style="min-height:40px; background-color:#F6F7F8; ">
     <h1>The Complete responsive CMS Blog</h1>
     <h1 class="lead">The Complete Blog By Using PHP</h1>
     <?php echo ErrorMessage();
           echo SuccessMessage();
     ?>
     <?php global $ConnectingDB;
     //SQL Query when Search btn is active...
     if(isset($_GET["SearchButton"])){
      $Search = $_GET["Search"];
      $sql = "SELECT * FROM posts
      WHERE datetime LIKE :search
      OR category LIKE :search
      OR title LIKE :search
      OR post LIKE :search
      OR image LIKE :search";
      $stmt = $ConnectingDB->prepare($sql);
      $stmt->bindValue(':search','%'.$Search.'%');
      $stmt->execute();
       }
       //Default Search Query...
     else {
       $PostIdFromURL = $_GET["id"];
       if (!isset($PostIdFromURL)) {
         $_SESSION["ErrorMessage"]="Bad Request !";
         Redirect_to("Blog.php");
       }
       $sql = "SELECT * FROM posts WHERE id='$PostIdFromURL'";
       $stmt = $ConnectingDB->query($sql);
     }
  while ($DataRows = $stmt->fetch()) {
  $PostId     = $DataRows["id"];
  $DateTime   = $DataRows["datetime"];
  $PostTitle  = $DataRows["title"];
  $Category   = $DataRows["category"];
  $Admin      = $DataRows["author"];
  $Image      = $DataRows["image"];
  $PostDescription = $DataRows["post"];
 ?>
   <div class="card">
     <img src="Uploads/<?php echo htmlentities( $Image); ?>" style="max height:450px;" class="img-fluid card-top"/>
     <div class="card-body">
       <h4 class="card-title"><?php echo htmlentities($PostTitle); ?></h4>
       <small class="text-muted"> Category : <span class="text-dark"><?php echo htmlentities($Category); ?></span> <br>Written by <span class="text-dark"><?php echo htmlentities($Admin); ?></span> On <span class="text-dark"><?php echo $DateTime; ?></span></small>
      <span style="float:right;" class="badge-dark text-light"><?php echo ApproveCommentsAccordingToPost($PostId); ?> people have commented on this post</span>
     <hr>
     <p class="card-text"><?php echo htmlentities($PostDescription); ?></p>
     </div>
   </div>
   <br>
             <?php } ?>
             <!-- Comment Part Start -->
             <!-- Fetching Existing Comment -->
             <span class="FieldInfo">Comments</span>
             <br><br>
        <?php
        global $ConnectingDB;
        $sql = "SELECT * FROM comments
        WHERE post_id='$SearchQueryParameter' AND status='ON'";
        $stmt =$ConnectingDB->query($sql);
        while ($DataRows = $stmt->fetch()) {
        $CommentDate     = $DataRows['datetime'];
        $CommenterName   = $DataRows['name'];
        $CommentContent  = $DataRows['comment'];

  ?>
  <div>

      <div class="media .CommentBlock">
      <div style="height:50px; width:50px;"><img class="d-block img-fluid align-self-start"src="Images/Commentator.png" alt=""></div>
        <div class="media-body ml-2">

          <h6 class="lead text-dark"><?php echo $CommenterName; ?></h6>
          <p class="small"><?php echo $CommentDate; ?></p>
          <p><?php echo $CommentContent; ?></p>
          </div>

        </div>
  </div>
  <hr>
<?php } ?>
            <!-- Fetching Existing Comment End -->
<div class="">
  <form class="" action="FullPost.php?id=<?php echo $SearchQueryParameter; ?>" method="post">
    <div class="card mb-3">
      <div class="card-header">
        <h5 class="FieldInfo">Share your thoughts about this post</h5>
        </div>

      <div class="card-body">
        <div class="form-group">
        <div class="input-group">
        <div class="input-group-prepend">
              <span class="input-group-text"><i class="fas fa-user"></i></span>
        </div>
             <input class="form-control" type="text" name="CommenterName" placeholder="Name" value="">
        </div>
        </div>
    <div class="form-group">
        <div class="input-group">
          <div class="input-group-prepend">
              <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            </div>
                <input class="form-control" type="email" name="CommenterEmail" placeholder="Email" value="">
          </div>
    </div>
    <div class="form-group">
      <textarea name="CommenterThoughts" class="form-control"rows="5" cols="80"></textarea>
    </div>
   <div class="">
     <button type="submit" name="Submit" class="btn btn-primary">Submit</button>

   </div>
      </div>
    </div>
  </form>
</div>
   <!-- Comment Part End -->
    </div>
   <!--Main Area End-->

   <!--Side Area-->
   <div class="col-sm-4">
     <div class="card mt-4">
       <div class="card-body">
         <img src="Images/Dell.jpg" class="d-block img-fluid mb-3"alt="">
         <div class="text-center">
           Ut bibendum odio sit amet congue convallis. Proin et suscipit ex, et venenatis nulla. Vestibulum suscipit velit ut massa convallis dictum in eget urna. Ut semper tincidunt tellus eget maximus. Integer risus velit, scelerisque in viverra in, dignissim in mi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin elementum sem non purus ultricies, ut mattis augue dictum.
         </div>
       </div>
      </div>
       <br>
       <div class="card">
         <div class="card-header bg-dark text-light">
            <h2 class="lead">Sign Up Now</h2>
         </div>
          <div class="card-body">
            <button type="button" class="btn btn-success btn-block text-center text-white mb-4"name="button">Join the Forum</button>
             <button type="button" class="btn btn-danger btn-block text-center text-white mb-4"name="button">Login</button>
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Enter Your Email"name="" value="">
           <div class="input-group-append">
             <button type="button" class="btn btn-primary btn-sm text-center text-white" name="button">Subscribe Now</button>
           </div>
          </div>
          </div>
       </div>

    <hr >
   <div class="card">
     <div class="card-header bg-primary text-white">
       <h2 class="lead FieldInfo" style="color:white;">Categories</h2>
       </div>
       <div class="card-body">
         <?php
            global $ConnectingDB;
            $sql = "SELECT * FROM category ORDER BY id desc";
            $stmt=$ConnectingDB->query($sql);
            while ($DataRows=$stmt->fetch()) {
              $CategoryId  = $DataRows["id"];
              $CategoryName   = $DataRows["title"];
         ?>
         <a href="Blog.php?category=<?php echo $CategoryName; ?>">
       <span class="heading FieldInfo" style="color:;" ><?php echo $CategoryName; ?></span><br></a>
        <?php } ?>
       </div>
 </div>
 <br>
<div class="card">
 <div class="card-header bg-info text-white">
   <h2 class="lead FieldInfo" style="color:white;">Recent Posts</h2>
 </div>
 <div class="card-body">
   <?php
     global $ConnectingDB;
     $sql= "SELECT * FROM posts ORDER BY id desc LIMIT 0,5";
     $stmt= $ConnectingDB->query($sql);
     while ($DataRows=$stmt->fetch()) {
       $Id       = $DataRows['id'];
       $Title     = $DataRows['title'];
       $DateTime   = $DataRows['datetime'];
       $Image     = $DataRows['image'];
   ?>
   <div class="media">
     <img src="Uploads/<?php echo htmlentities($Image); ?>" class="d-block img-fluid align-self-start" width="90" height="95" alt="">
     <div class="media-body ml-2">
     <a href="FullPost.php?id=<?php echo htmlentities($Id); ?>" target="_blank">  <h6 class="lead FieldInfo" style="color:#0090DB;"><?php echo htmlentities($Title); ?></h6></a>
       <p class="small"><?php echo htmlentities($DateTime); ?></p>
     </div>
   </div>
   <hr>
 <?php } ?>
 </div>

</div>


   </div>
   <!--Side Area End-->
  </div>

</div>

    <!--HEADER END-->
    <br>
    <!-- FOOTER -->
      <div style="height:10px; background:#27aae1;"></div>
   <footer class="bg-dark text-white">
   <div class="container">
     <div class="row">
   <div class="col">
      <p class="lead text-center">This is a sample footer | <span id="year"></span> &copy --- All rights reserved</p>
     </div>
     </div>
     </div>
   </footer>
   <div style="height:10px; background:#27aae1;"></div>
   <!--FOOTER END-->


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
 <script>
   $('#year').text(new Date().getFullYear());
 </script>

  </body>
  </html>
