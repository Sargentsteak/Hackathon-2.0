<?php
$DSN='mysql:host = localhost; dbname=cms';
$ConnectingDB = new PDO($DSN,'root','');
?>
