<?php require_once("functions.php");
session_start();
?>

<?php
if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}


include 'header.php'; ?>

<?php 


if ($_SESSION["USER"]->USER_TYPE == "MANAGER")
  $Projectdata=getAllProjects();

if ($_SESSION["USER"]->USER_TYPE == "TEAMLEAD")
  $Projectdata=getAllProjectByTeamLeadID($_SESSION["USER"]->ID);

$teamlead=getAllUsersByType("TEAMLEAD");

?>



<div style="margin-left: 25%;">
  <h2 style="padding-left: 75px;"> Create new Project </h2>
  <form action = "controllers/ProjectController.php" method = "POST">
   
<input type="hidden" name="projectManager" value="<?php echo $_SESSION["USER"]->ID ?>" required>
    <label class="form-control-label" style="padding-top: 50px;">Project Name: </label>
    <input type="text" class="form-control" style="width: 500px;" name="projectName" value="" required><br>
    <label class="form-control-label">Discription : </label>
    <input type="text" class="form-control" style="width: 500px;" name="projectDescription" value="" required><br>
    Priority :<input type="number" class="form-control" style="width: 500px;" name="projectPriority" value="" required min="1" max="5">
    <br><label class="form-control-label">Team Lead : </label>
    <select name="teamLead" class="form-control" style="width: 500px;">
      <option disabled>Select Team Lead</option>

    <?php 
    foreach ($teamlead as $lead) { 
            
        ?>
        <option value="<?php echo $lead->ID ?>">
        <?php echo $lead->USERNAME ?>
        </option>
    <?php } ?>
  </select><br>
    <input type="submit" class="btn btn-primary" name="Submit" value="Create">
</form>

  
</div>

<hr>

<?php if ($Projectdata != null) { ?>



<h2> List Project</h2>

<table class="table">
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Project Id</th>
      <th scope="col">Name</th>
      <th scope="col">Manager</th>
      <th scope="col">Priority</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
<?php 
foreach ($Projectdata as $project) { ?>
 
 <tr>
      <td><?php echo $project->ID ?></td>
      <td><?php echo getUserByID($project->MANAGER_ID)->USERNAME ?></td>
      <td><?php echo $project->NAME ?></td>
      <td><?php echo $project->PRIORITY?></td>
      <td>
        <form action = "ProjectViewDetails.php" method = "GET">
            <input type="hidden" name="projectId" value="<?php echo $project->ID ?> ">
            <input type="submit" name="Submit" value="View Details">
        </form>
      </td>
    </tr>

    
    <?php } ?>

<tbody>
</table>

<?php } else{ ?>
 You have no projects in the system

<?php } ?>



<?php include 'footer.php';?>