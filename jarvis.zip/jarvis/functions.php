<?PHP

    require_once("constants.php");
    
    /// redirect to any page
    function redirect_to($location){
        header('Location:'.$location);
    }


    function db_connect(){

            // Create connection
            $connection = new mysqli(C_DB_HOST, C_DB_USERNAME, C_DB_PASSWORD, C_DB_NAME);

            // Check connection
            if ($connection->connect_error) {
                die("Connection failed: " . $connection->connect_error);
            }
            return $connection;
    }

    function db_close($connection){
        $connection->close();
    }

    function perform_query($query){
        // Perform query
        if ($result = $mysqli -> query($query)) {
            return $result;    
        }
        return null;
    }

    function login_attempt($username,$password){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE USERNAME = '".$username."' AND PASSWORD='".$password."'";

       
        if($result = mysqli_query($connection, $query)){
            
            if(mysqli_num_rows($result) > 0){

                db_close($connection);
                return true;
            }
            else{
;
                db_close($connection);
                return false;
            }
        }
        db_close($connection);
        return false;
    }

    function getUserByUserName($username){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE USERNAME = '".$username."'";


        if($result = mysqli_query($connection, $query)){
            if(mysqli_num_rows($result) > 0){
                
                $row = $result -> fetch_object();

                db_close($connection);
                return $row;
            }
        }
        db_close($connection);
        return null;
    }

    function getUserByID($id){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE ID = '".$id."'";


        if($result = mysqli_query($connection, $query)){
            if(mysqli_num_rows($result) > 0){
                
                $row = $result -> fetch_object();

                db_close($connection);
                return $row;
            }
        }
        db_close($connection);
        return null;
    }

    function getAllUsersByType($type){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE USER_TYPE = '".$type."'";


        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }



        db_close($connection);
        return null;
    }

    function getAllProjects(){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_PROJECT";

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }



    function getProjectByID($id){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_PROJECT WHERE ID = ".$id;

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }


    function getAllProjectByTeamLeadID($teamlead){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_PROJECT WHERE TEAMLEAD_ID = ".$teamlead;

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }


    


    function createProject($projectName, $projectPriority, $projectDescription, $projectManager ,$teamlead){
        $connection = db_connect();

        if ($projectDescription == null){
            $query = "INSERT INTO JARVIS_PROJECT (MANAGER_ID, NAME, PRIORITY, DESCRIPTION, TEAMLEAD_ID) VALUE (".$projectManager.",'".$projectName."',".$projectPriority .",'".$projectDescription."',".$teamlead.")";
        }else{
            $query = "INSERT INTO JARVIS_PROJECT (MANAGER_ID, NAME, PRIORITY, DESCRIPTION, TEAMLEAD_ID) VALUE (".$projectManager.",'".$projectName."',".$projectPriority .",null,".$teamlead.")";
        }
        if ($connection->query($query) === TRUE) {
            db_close($connection);
            return true; 
          } else {
            
            echo $query;
            echo "Error: " . $connection . "<br>" . $connection->error;
            db_close($connection);
            return false;
          }
    }





