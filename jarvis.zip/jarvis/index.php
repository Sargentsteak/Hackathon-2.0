<?php require_once("functions.php");
session_start();
?>

<?php
if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}


include 'header.php'; ?>

<h2>dashboard</h2>

Hello
<?php 
include 'footer.php';