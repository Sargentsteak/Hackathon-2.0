<?php require_once("Functions.php"); ?>

<?php
$_SESSION["User_ID"]=null;
$_SESSION["UserName"]=null;

session_destroy();
redirect_to("login.php")

 ?>
