<?php require_once("functions.php");
session_start();
?>

<?php
if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}


if ($_SESSION["USER"]->USER_TYPE == "MANAGER")
    $ProjectDetails =  getProjectByID($_GET["projectId"]);

if ($_SESSION["USER"]->USER_TYPE == "TEAMLEAD")
    $ProjectDetails =  getAllProjectByTeamLeadID($_GET["projectId"]);

include 'header.php'; ?>


<a href="projects.php"> Go back </a>

Project details :

ID: 
<?php echo  $ProjectDetails [0]-> ID ?>


MANAGER : <?php echo  getUserByID ( $ProjectDetails[0]-> MANAGER_ID ) -> USERNAME ?>

ID: 
<?php echo  $ProjectDetails [0]-> ID ?>


TeamLead : <?php echo   getUserByID ( $ProjectDetails[0]-> TEAMLEAD_ID ) -> USERNAME ?>

Priority: 
<?php echo  $ProjectDetails [0]-> PRIORITY ?>

Description
<?php echo  $ProjectDetails[0]-> DESCRIPTION ?>



<h2>
Create task ... WIP
</h2>
