<!-- Footer -->
<footer class="bg-light" style="width: 100%;">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <span> JARVIS - All rights reserved </span>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
</body>
</html>

