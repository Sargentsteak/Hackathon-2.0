<?php include 'header.php'; ?>
<div class="card" style="width: 500px;margin-left: 300px;">
  <div class="card-header ">
    Forgot Password
  </div>
  <div class="card-body" style="padding-left: 125px;">
    <form action = "controllers/ProjectController.php" method = "POST">
   
<input type="hidden" name="projectManager" value="<?php echo $_SESSION["USER"]->ID ?>" required>
    <label class="form-control-label">Username: </label>
    <input type="text" class="form-control" style="width: 200px;" name="username" value="" required><br>
    <label class="form-control-label" tyle="padding-top: 50px;">Password: </label>
    <input type="text" class="form-control" style="width: 200px;" name="password" value="" required><br>
    <label class="form-control-label">Confirm Password: </label>
    <input type="text" class="form-control" style="width: 200px;" name="password" value="" required><br>
    <input type="submit" class="btn btn-primary" style="margin-left: 60px;" name="Submit" value="Submit">
</form>

  </div>
</div>

<?php include('footer.php'); ?>