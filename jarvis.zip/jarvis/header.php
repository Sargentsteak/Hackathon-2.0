<?php 

require_once("functions.php");
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 
$user=$_SESSION["USER"];
?>

<!DOCTYPE html>
  <html lang="en" dir="ltr">
  <head>
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link rel="stylesheet" href="css/styles.css">
  
  </head>

  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Jarvis</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
     
     <?php if ($user->USER_TYPE == "MANAGER"){ ?>
      <a class="nav-item nav-link" href="./">Dashboard</a>
      <a class="nav-item nav-link" href="./projects.php">Projects</a>
      
     <?php } ?>
      
     <?php if ($user->USER_TYPE == 'TEAMLEAD'){ ?>
      <a class="nav-item nav-link" href="./projects.php">My Project</a>
      <a class="nav-item nav-link" href="addnewtask.php">Add New Tasks</a>
      <a class="nav-item nav-link" href="#">Renew</a>
      <a class="nav-item nav-link" href="#">Approvals</a>
     <?php } ?>

     <?php if ($user->USER_TYPE == 'RESOURCE'){ ?>
      <a class="nav-item nav-link" href="projects.php">Dashboard</a>
      <a class="nav-item nav-link" href="projects.php">My Tasks</a>
      
     <?php } ?>


     <?php if ($user->USER_TYPE == 'MANAGER'){ ?>
      <a class="nav-item nav-link" href="users.php">Users</a>
     <?php } ?>

     <a class="nav-item nav-link" href="settings.php">Settings</a>
     <a class="nav-item nav-link" href="./controllers/logoutController.php">Logout</a>
      
    </div>
  </div>
</nav>

  <div class="container"  >
    
  </div>
<hr>
   