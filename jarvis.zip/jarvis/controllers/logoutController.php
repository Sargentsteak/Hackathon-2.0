<?php require_once("../functions.php"); 


if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

session_destroy();
redirect_to("../index.php")

?>