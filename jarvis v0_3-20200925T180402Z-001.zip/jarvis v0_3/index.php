<?php require_once("functions.php");
session_start();
?>

<?php
if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}


include 'header.php'; ?>

<h2>dashboard</h2>

<div class="card" style="width: 18rem;">
 
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

    <div class="progress">
  <div class="progress-bar bg-danger" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
</div>

<button type="button" class="btn btn-danger">Primary</button>
  </div>
</div>
<?php 
include 'footer.php';