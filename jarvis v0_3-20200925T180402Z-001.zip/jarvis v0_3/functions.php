<?PHP

    require_once("constants.php");
    
    /// redirect to any page
    function redirect_to($location){
        header('Location:'.$location);
    }


    function db_connect(){

            // Create connection
            $connection = new mysqli(C_DB_HOST, C_DB_USERNAME, C_DB_PASSWORD, C_DB_NAME);

            // Check connection
            if ($connection->connect_error) {
                die("Connection failed: " . $connection->connect_error);
            }
            return $connection;
    }

    function db_close($connection){
        $connection->close();
    }

    function perform_query($query){
        // Perform query
        if ($result = $mysqli -> query($query)) {
            return $result;    
        }
        return null;
    }

    function login_attempt($username,$password){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE USERNAME = '".$username."' AND PASSWORD='".$password."'";

       
        if($result = mysqli_query($connection, $query)){
            
            if(mysqli_num_rows($result) > 0){

                db_close($connection);
                return true;
            }
            else{
;
                db_close($connection);
                return false;
            }
        }
        db_close($connection);
        return false;
    }

    function getUserByUserName($username){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE USERNAME = '".$username."'";


        if($result = mysqli_query($connection, $query)){
            if(mysqli_num_rows($result) > 0){
                
                $row = $result -> fetch_object();

                db_close($connection);
                return $row;
            }
        }
        db_close($connection);
        return null;
    }

    function getUserByID($id){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE ID = '".$id."'";


        if($result = mysqli_query($connection, $query)){
            if(mysqli_num_rows($result) > 0){
                
                $row = $result -> fetch_object();

                db_close($connection);
                return $row;
            }
        }
        db_close($connection);
        return null;
    }

    function getAllUsersByType($type){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS WHERE USER_TYPE = '".$type."'";


        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }



        db_close($connection);
        return null;
    }

    function getAllProjects(){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_PROJECT";

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }



    function getProjectByID($id){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_PROJECT WHERE ID = ".$id;

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }


    function getAllProjectByTeamLeadID($teamlead){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_PROJECT WHERE TEAMLEAD_ID = ".$teamlead;

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }


    


    function createProject($projectName, $projectPriority, $projectDescription, $projectManager ,$teamlead){
        $connection = db_connect();

        if ($projectDescription == null){
            $query = "INSERT INTO JARVIS_PROJECT (MANAGER_ID, NAME, PRIORITY, DESCRIPTION, TEAMLEAD_ID) VALUE (".$projectManager.",'".$projectName."',".$projectPriority .",'".$projectDescription."',".$teamlead.")";
        }else{
            $query = "INSERT INTO JARVIS_PROJECT (MANAGER_ID, NAME, PRIORITY, DESCRIPTION, TEAMLEAD_ID) VALUE (".$projectManager.",'".$projectName."',".$projectPriority .",null,".$teamlead.")";
        }
        if ($connection->query($query) === TRUE) {
            db_close($connection);
            return true; 
          } else {
            
            echo $query;
            echo "Error: " . $connection . "<br>" . $connection->error;
            db_close($connection);
            return false;
          }
    }



    function  createNewTaskHistory($taskId,$ResourceId, $TeamLeadId ){
        $connection = db_connect();
        $query =     $query = "INSERT INTO JARVIS_TASK_HISTORY ( TASK_ID , RESOURCE_ID ,  TEAMLEAD_ID , SEQUENCE_NUMBER , TEAMLEAD_TASK_COMMENT,  APPROVAL_STATUS , PERCENT_COMPLETED , COMMIT_DATE )  VALUE (".$taskId.",".$ResourceId.",".$TeamLeadId.",0,'CREATED NEW TASK', 'A'  , 0 , CURDATE() )";

        echo $query;
        if ($connection->query($query) === TRUE) {
            db_close($connection);
            return true; 
          } else {
            
            echo $query;
            echo "Error: " . $connection . "<br>" . $connection->error;
            db_close($connection);
            return false;
          }

    }


    function createNewTask($TeamLeadId,$ResourceId, $TaskName ,$TaskPriority , $TaskDescription , $TaskPercentCompelete , $TaskCurrentStatus , $Projectid){
        $connection = db_connect();

        if ($TaskDescription != null){
            $query = "INSERT INTO JARVIS_TASK ( TEAMLEAD_ID, RESOURCE_ID, NAME, PRIORITY, DESCRIPTION, PERCENT_COMPLETED, CURRENT_STATUS, PENDING_APPROVAL_FLAG,PROJECT_ID) VALUE (".$TeamLeadId.",".$ResourceId.",'".$TaskName."',".$TaskPriority .",'".$TaskDescription."',".$TaskPercentCompelete.",'".$TaskCurrentStatus."','N',".$Projectid.")";
        }
        else{
            $query = "INSERT INTO JARVIS_TASK ( TEAMLEAD_ID, RESOURCE_ID, NAME, PRIORITY, PERCENT_COMPLETED, CURRENT_STATUS, PENDING_APPROVAL_FLAG,PROJECT_ID) VALUE (".$TeamLeadId.",".$ResourceId.",'".$TaskName."',".$TaskPriority .",".$TaskPercentCompelete. ",'".$TaskCurrentStatus."','N',".$Projectid.")";
        }    
        
        echo $query;


        if ($connection->query($query) === TRUE) {
           

            $taskId = mysqli_insert_id($connection);
            //createNewTaskHistory()
            db_close($connection);
            if (createNewTaskHistory($taskId,$ResourceId, $TeamLeadId)){
                return true; 
            }else{
                return false;
            }
            
          } else {
            
            echo $query;
            echo "Error: " . $connection . "<br>" . $connection->error;
            db_close($connection);
            return false;
          }
    }




    function getAllTaskByProjectID($projectId){
        
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_TASK WHERE PROJECT_ID = ".$projectId;

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }


    function createUser($username, $password, $usertype,$email){
        $connection = db_connect();
        $query = "INSERT INTO JARVIS_USERS ( USERNAME , PASSWORD ,  EMAIL , USER_TYPE )  VALUE ('".$username."','".$password."','".$email."','".$usertype."')";

        echo $query;
        if ($connection->query($query) === TRUE) {
            db_close($connection);
            return true; 
          } else {
            
            echo $query;
            echo "Error: " . $connection . "<br>" . $connection->error;
            db_close($connection);
            return false;
          }
    }


    function getAllUser(){
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_USERS";

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }      



    function getTaskDetailsByID($taskId){
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_TASK WHERE ID = ".$taskId;

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }      
    

    function getTaskHistoryByTaskID($taskId){
        $connection = db_connect();
        $query = "SELECT * FROM JARVIS_TASK_HISTORY WHERE TASK_ID = ".$taskId .' ORDER BY SEQUENCE_NUMBER DESC';

      
        if($result = mysqli_query($connection, $query)){
           
   
            if(mysqli_num_rows($result) > 0){
                
                $data = [];
                while($row = $result -> fetch_object()){
                    
                   $data[]=$row;
                }

                db_close($connection);
               return $data;
            }
        }

        db_close($connection);
        return null;
    }      