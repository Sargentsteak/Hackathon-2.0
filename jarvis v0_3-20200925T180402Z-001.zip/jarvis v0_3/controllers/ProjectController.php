<?PHP
require_once("../functions.php");
session_start();

$projectName = $_POST["projectName"];
$projectPriority = $_POST["projectPriority"];
$projectDescription = $_POST["projectDescription"];
$projectManager = $_POST["projectManager"];
$teamlead = $_POST ["teamLead"];


if ( $projectDescription == '' ) 
    $projectDescription = null;

if( createProject($projectName, $projectPriority, $projectDescription, $projectManager ,$teamlead) ){
    Redirect_to("../projects.php");
}