<?PHP
require_once("../functions.php");
session_start();

if( $_POST["Username"] || $_POST["Password"] ) {

    if ( login_attempt ($_POST["Username"],$_POST["Password"]) ){
        $data=getUserByUserName($_POST["Username"]);
        
        $_SESSION["USER"] = $data;
        
        print_r($_SESSION);
        Redirect_to("../index.php");

    }else{
        echo 1;
        $_SESSION["ALERT_MESSAGE"] = "Invalid Credentials";
        $_SESSION["ALERT_TYPE"] =  "error";
    }
}
else{
    echo 2;
    $_SESSION["ALERT_MESSAGE"] = "Invalid Parameter";
    $_SESSION["ALERT_TYPE"] =  "error";
}
Redirect_to("../login.php");
?>