<?PHP 
define("C_DB_HOST",     "localhost");
define("C_DB_USERNAME",     "ROOT");
define("C_DB_PASSWORD",     "");
define("C_DB_NAME",     "JARVIS");


