<?php require_once("functions.php");
session_start();

if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}


/// we use this as view for task

if ($_SESSION["USER"]->USER_TYPE == "MANAGER")
    $ProjectDetails =  getProjectByID($_GET["projectId"]);

if ($_SESSION["USER"]->USER_TYPE == "TEAMLEAD")
    $ProjectDetails =  getAllProjectByTeamLeadID($_SESSION["USER"]->ID);

if ($_SESSION["USER"]->USER_TYPE == "RESOURCE")
    $ProjectDetails =  getAllProjectByResource($_SESSION["USER"]->ID);

    $Resourcelist=getAllUsersByType("RESOURCE");
    $taskList = getAllTaskByProjectID($_GET["projectId"]);


include 'header.php'; ?>






<?PHP if ($_SESSION["USER"]->USER_TYPE == "TEAMLEAD") { ?>

 
<div class="card" style="margin-top: 25px;width: 100%;">
  <div class="card-header">
    <H2> Create Task</H2> 
  </div>
  <div class="card-body">
    <form action = "controllers/createTaskController.php" method = "POST">
   
   <input type="hidden" name="project_id" value="<?php echo $_GET["projectId"] ?>"> 
   <input type="hidden" name="TeamLead" value="<?php echo $_SESSION["USER"]->ID ?>" required>
   <input type="hidden" name="TaskPercentComplete" value="0" required>
   <input type="hidden" name="TaskCurrentStatus" value="New" required>
   

   <div class="form-group">
    <label for="exampleInputEmail1">Project Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Task Name" name="TaskName" required>

  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Task Description</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Task Description" name="TaskDescription">

  </div>



  <div class="form-group">
    <label for="exampleInputEmail1">Task Priority</label>
    <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Task Priority" name="TaskPriority" required min=1 max=5>

  </div>

  
  <div class="form-group">
  <label for="exampleFormControlSelect1">Resource</label>
   
    <select class="form-control" id="exampleFormControlSelect1" name="resource" required>
    <option disabled>Select Resource</option>
    <?php 
    foreach ($Resourcelist as $resource) { 
            
        ?>
        <option value="<?php echo $resource->ID ?>">
        <?php echo $resource->USERNAME ?>
        </option>
    <?php } ?>

    </select>

  </div>


  <input type="submit" class="btn btn-primary" name="Submit" value="Create">
  <button class="btn btn-primary"><a href="projects.php" style="color: white;text-decoration: none;"> Go back </a></button>
  

 </form>
</div>
</div><hr> 

<?PHP } ?>



<div class="card">
  <div class="card-header">
    <h3>Project</h3>
  </div>
  <div class="card-body">
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Name</th>
        <th scope="col">Manager</th>
        <th scope="col">Priority</th>
        <th scope="col">Discription</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo  $ProjectDetails [0]-> ID ?></td>
        <td><?php echo  $ProjectDetails [0]-> NAME ?></td>
        <td><?php echo  getUserByID ( $ProjectDetails[0]-> MANAGER_ID ) -> USERNAME ?></td>
        <td><?php echo  $ProjectDetails [0]-> PRIORITY ?></td>
        <td><?php echo  $ProjectDetails[0]-> DESCRIPTION ?></td></tr>

  </tbody>
  </table>
</div>
</div><hr>

      </DIV>



<div class="card">
  <div class="card-header">
    <h3>Task List</h3>
  </div>
  <div class="card-body">


<?php if ($taskList != null) { ?>

  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">TEAMLEAD</th>
        <th scope="col">RESOURCE</th>
        <th scope="col">NAME</th>
        <th scope="col">PRIORITY</th>
        <th scope="col">DESCRIPTION</th>
        <th scope="col">PERCENT_COMPLETED</th>
        <th scope="col">CURRENT_STATUS</th>
        <th scope="col">PENDING_APPROVAL_FLAG</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
  <?php 
  foreach ($taskList as $task) { ?>

  <tr>
        <td><?php echo $task->ID ?></td>
        <td><?php echo getUserByID($task->TEAMLEAD_ID)->USERNAME ?></td>
        <td><?php echo getUserByID($task->RESOURCE_ID)->USERNAME ?></td>
        <td><?php echo $task->NAME ?></td>
        <td><?php echo $task->PRIORITY?></td>
        <td><?php echo $task->DESCRIPTION?></td>
        <td>
          <div class="progress">
           <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width:<?php echo $task->PERCENT_COMPLETED?>%" aria-valuenow=" <?php echo $task->PERCENT_COMPLETED?>" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
  <?php echo $task->PERCENT_COMPLETED?>%
      </td>
        <td><?php echo $task->CURRENT_STATUS?></td>
        <td><?php echo $task->PENDING_APPROVAL_FLAG?></td>
        
        <td>
          <form action = "ViewTaskDetails.php" method = "GET">
              <input type="hidden" name="projectId" value="<?php echo $_GET["projectId"] ?> ">
              <input type="hidden" name="taskID" value="<?php echo $task->ID ?> ">
              <input type="submit"  class="btn btn-primary" name="Submit" value="View details">
          </form>
        </td>
      </tr>
    <?php } ?>

  </tbody>
  </table>


  <?PHP }else{?>

 You have no any task defined for this project
<?php } ?>
  </div>
</div>
