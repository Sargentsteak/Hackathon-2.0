<?PHP
require_once("functions.php");

if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

if (isset($_SESSION["USER"])) {
    Redirect_to("index.php");
  }
?>


<!DOCTYPE html>
  <html lang="en" dir="ltr">
  <head>
  
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="css/login.css">
  
  
  </head>

  <body>

  <div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    
<?PHP

    if (isset($_SESSION["ALERT_TYPE"])) {
        ?>

            <div class="alert alert-<?php echo $_SESSION["ALERT_TYPE"]?>" role="alert">
                <?php echo $_SESSION["ALERT_MESSAGE"]?>
            </div>

        <?PHP
        unset ($_SESSION["ALERT_TYPE"]);
        unset ($_SESSION["ALERT_MESSAGE"]);
    }
?>

             <!-- Icon -->
    <div class="fadeIn first">
      <img src="http://danielzawadzki.com/codepen/01/icon.svg" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form class="" action="controllers/loginController.php" method="post">
    
      <input type="text" id="login" class="fadeIn second" name="Username" placeholder="login" value="" required>
      <input type="password" id="password" class="fadeIn third" name="Password" placeholder="password" value="" required>
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
    </div>

  </div>
</div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>