<?php require_once("functions.php");
session_start();

if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}


/// we use this as view for Task Details

$taskDetail = getTaskDetailsByID($_GET["taskID"]);  

// VIEW TASK DETAIL 
include 'header.php'; ?>


<h2> tASK Details</h2>

<li class="list-group-item"><b>ID </b><?php echo  $taskDetail [0]-> ID ?></li>
<li class="list-group-item"><b>Project ID </b><?php echo  $taskDetail [0]-> PROJECT_ID ?></li>
<li class="list-group-item"><b>Resource </b><?php echo  getUserByID ( $taskDetail[0]-> RESOURCE_ID ) -> USERNAME ?> </li>
<li class="list-group-item"><b>Name </b><?php echo  $taskDetail [0]-> NAME ?></li>
<li class="list-group-item"><b>PRIORITY </b><?php echo  $taskDetail[0]-> PRIORITY ?></li>

<li class="list-group-item"><b>TeamLead </b><?php echo  getUserByID ( $taskDetail[0]-> TEAMLEAD_ID ) -> USERNAME ?> </li>
<li class="list-group-item"><b>DESCRIPTION </b><?php echo  $taskDetail[0]-> DESCRIPTION ?></li>

<li class="list-group-item"><b>Task cOMPLETED </b>
<div class="progress">
           <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width:<?php echo $taskDetail[0]->PERCENT_COMPLETED?>%" aria-valuenow=" <?php echo $taskDetail[0]->PERCENT_COMPLETED?>" aria-valuemin="0" aria-valuemax="100"></div>
          </div>

<?php echo  $taskDetail[0]-> PERCENT_COMPLETED ?></li>


<li class="list-group-item"><b>CURRENT_STATUS </b><?php echo  $taskDetail[0]-> CURRENT_STATUS ?></li>

/// VIEW TASK HOSTORY
<?

$taskHistoryList=getTaskHistoryByTaskID($taskDetail [0]-> ID)
?>



<?php
$sequence = 0;

if ($taskHistoryList != null) { ?>
  <h2> List Task History</h2>

  <table class="table">
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Resource</th>
        <th scope="col">TEAMLEAD</th>
        <th scope="col">RESOURCE_TASK_COMMENT</th>
        <th scope="col">TEAMLEAD_TASK_COMMENT</th>
        <th scope="col">APPROVAL_STATUS</th>
        <th scope="col">PERCENT_COMPLETED</th>
        <th scope="col">COMMIT_DATE</th>
      </tr>
    </thead>
    <tbody>
  <?php 
  foreach ($taskHistoryList as $taskHistory) {
    $sequence++;
    ?>

  <tr>
  <td><?php echo getUserByID($taskHistory->RESOURCE_ID)->USERNAME ?></td>
  <td><?php echo getUserByID($taskHistory->TEAMLEAD_ID)->USERNAME ?></td>
        <td><?php echo $taskHistory->RESOURCE_TASK_COMMENT ?></td>
        <td><?php echo $taskHistory->TEAMLEAD_TASK_COMMENT ?></td>

        <td><?php echo $taskHistory->APPROVAL_STATUS ?></td>
        <td>

          <div class="progress">
           <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width:<?php echo $taskHistory->PERCENT_COMPLETED?>%" aria-valuenow=" <?php echo $taskHistory->PERCENT_COMPLETED?>" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
                <?php echo $taskHistory->PERCENT_COMPLETED?>%
      </td>


      </td>

        <td><?php echo $taskHistory->COMMIT_DATE?></td>

        </tr>
    <?php } ?>

  <tbody>
  </table>


  <?PHP }else{?>

 You have no any task defined for this project
<?php } 

//


?>


<?php if ($_SESSION["USER"]->USER_TYPE != "MANAGER"){ ?>


<H2> Edit Task </H2> 


<form action = "controllers/editTaskContorller.php" method = "POST">
   
   <input type="hidden" name="task_id" value="<?php echo $taskDetail [0]-> ID ?>"> 
   <input type="hidden" name="user_id" value="<?php echo $_SESSION["USER"]->ID ?>"> 
   <input type="hidden" name="project_id" value="<?php echo  $taskDetail [0]-> PROJECT_ID ?>"> 
   <input type="hidden" name="team_lead_id" value="<?php echo $taskDetail[0]-> TEAMLEAD_ID ?>"> 
   <input type="hidden" name="resouce_id" value="<?php echo $taskDetail[0]-> RESOURCE_ID ?>"> 
   <input type="hidden" name="Varseqeunce" value="<?php echo $sequence ?>"> 


    <?php if ($_SESSION["USER"]->USER_TYPE == "TEAMLEAD"){ ?>
      tlCOMMENT<input type="text" name="teamLeadComment" value="">
    <? } if ($_SESSION["USER"]->USER_TYPE == "RESOURCE"){ ?>
      rESOURCE COMMENT<input type="text" name="resourceComment" value="">
<?    } ?>

   
   

  peRCENT COMPLETE <input type="number" name="percentComplete" min=1 max=100>


    <select class="form-control" id="exampleFormControlSelect1" name="status" required>
    <option disabled>Select Resource</option>
    <option >NEW</option>
    <option >BACKLOG</option>
    <option >OPEN</option>
    <option >INPROGRESS</option>
    </select>


  <input type="submit" class="btn btn-primary" name="Submit" value="Create">
  

 </form>


<?php
}


include 'footer.php';?>



