<?php require_once("functions.php");
session_start();




if (!isset($_SESSION["USER"])) {
  Redirect_to("login.php");
}

/// we use this as view for Project

include 'header.php'; ?>

<?php 


if ($_SESSION["USER"]->USER_TYPE == "MANAGER")
  $Projectdata=getAllProjects();

if ($_SESSION["USER"]->USER_TYPE == "TEAMLEAD")
  $Projectdata=getAllProjectByTeamLeadID($_SESSION["USER"]->ID);

if ($_SESSION["USER"]->USER_TYPE == "RESOURCE")
  $Projectdata=getAllProjectByResource($_SESSION["USER"]->ID);

$teamlead=getAllUsersByType("TEAMLEAD");

?>

<?PHP 

if ($_SESSION["USER"]->USER_TYPE == "MANAGER") {

  ?>
 

 <div class="row">
    <div class="col-2">
      
    </div>
    <div class="col-8">
  

    <div class="card ">
  <div class="card-header alert-dark" style="padding-left: 325px;">
    Create New Project
  </div>
  <div class="card-body" >

    <form action = "controllers/ProjectController.php" method = "POST">
    
    <input type="hidden" name="projectManager" value="<?php echo $_SESSION["USER"]->ID ?>" required>

        
        <label class="form-control-label" >Project Name: </label>
        <input type="text" class="form-control"  name="projectName" value="" required><br>
        <label class="form-control-label">Discription : </label>
        <input type="text" class="form-control"  name="projectDescription" value="" required><br>
        Priority :<input type="number" class="form-control"  name="projectPriority" value="" required min="1" max="5">
        <br><label class="form-control-label">Team Lead : </label>
        <select name="teamLead" class="form-control" >
          <option disabled>Select Team Lead</option>
    
        <?php 
        foreach ($teamlead as $lead) { 
                
            ?>
            <option value="<?php echo $lead->ID ?>">
            <?php echo $lead->USERNAME ?>
            </option>
        <?php } ?>
      </select>
      </select><br>
      <input type="submit" style="margin-left: 125px;" class="btn btn-primary" name="Submit" value="Create">
    </form>
  </div>
</div>



    </div>
    <div class="col-2">
      
    </div>
  </div>






<?PHP }?>
<hr>

<?php if ($Projectdata != null) { ?>



<h2> List Project</h2>
<div class="table-responsive">

<table class="table">
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Project Id</th>
      <th scope="col">Manager</th>
      <th scope="col">Name</th>
      <th scope="col">Priority</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
<?php 
foreach ($Projectdata as $project) { ?>
 
 <tr>
    <td><?php echo $project->ID ?></td>
    <td><?php echo getUserByID($project->MANAGER_ID)->USERNAME ?></td>
    <td><?php echo $project->NAME ?></td>
    <td><?php echo $project->PRIORITY?></td>
    <td>
      <form action = "ProjectViewDetails.php" method = "GET">
          <input type="hidden" name="projectId" value="<?php echo $project->ID ?>">
          <input type="submit" name="Submit" value="View Details">
      </form>
    </td>
  </tr>

    
    <?php } ?>

<tbody>
</table>
</div>

<?php } else{ ?>
 You have no projects in the system

<?php } ?>



<?php include 'footer.php';