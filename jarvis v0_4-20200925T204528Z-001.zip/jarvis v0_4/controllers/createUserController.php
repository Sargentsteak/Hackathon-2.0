<?PHP
require_once("../functions.php");
session_start();

$username = $_POST["username"];
$password = $_POST["password"];
$usertype = $_POST["usertype"];

$email= $_POST["email"];

if( createUser($username, $password, $usertype,$email) ){
    Redirect_to("../users.php");
}