<?PHP
require_once("../functions.php");
session_start();

$taskId = $_POST["task_id"];
$user_id = $_POST["user_id"];
$project_id = $_POST ["project_id"]; 
$team_lead_id = $_POST["team_lead_id"];
$resouce_id = $_POST["resouce_id"];
$resourceComment = $_POST["resourceComment"];
$teamLeadComment = $_POST["teamLeadComment"];
$percentComplete = $_POST["percentComplete"];
$status = $_POST["status"];
$Varseqeunce=$_POST["Varseqeunce"];


$user=getUserByID($user_id);

if ($user->USER_TYPE == 'TEAMLEAD'){
    createNewTaskHistory($taskId,$resouce_id, $team_lead_id,$Varseqeunce, $teamLeadComment , $resourceComment ,$percentComplete,'A',$status);
        Redirect_to("../ViewTaskDetails.php?projectId=1+&taskID=1+&Submit=View+details");
}


if ($user->USER_TYPE == 'RESOURCE'){
    createNewTaskHistory($taskId,$resouce_id, $team_lead_id,$Varseqeunce, $teamLeadComment , $resourceComment ,$percentComplete,'P',$status);
     Redirect_to("../ViewTaskDetails.php?projectId=1+&taskID=1+&Submit=View+details");
}

