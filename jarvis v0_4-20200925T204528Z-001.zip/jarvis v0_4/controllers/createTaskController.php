<?PHP
require_once("../functions.php");
session_start();


$TeamLeadId=$_POST ["TeamLead"];
$ResourceId=$_POST ["resource"];
$TaskName=$_POST ["TaskName"];
$TaskPriority=$_POST ["TaskPriority"];
$TaskDescription=$_POST ["TaskDescription"];
$TaskPercentCompelete=$_POST ["TaskPercentComplete"];
$TaskCurrentStatus=$_POST ["TaskCurrentStatus"];

$Projectid=$_POST ['project_id'];

if ( $TaskDescription == '' ) 
    $TaskDescription = null;

if( createNewTask($TeamLeadId,$ResourceId, $TaskName ,$TaskPriority , $TaskDescription , $TaskPercentCompelete , $TaskCurrentStatus , $Projectid)){
    Redirect_to("../ProjectViewDetails.php?projectId=".$Projectid);
}




